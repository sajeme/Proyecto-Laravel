<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion Clientes </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h4>Nuevo Cliente</h4>
        <div class="row">
            <div class="col-sm-4 my-1">
                <form action="<?php echo e(route('cliente.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nombre">nombre</label>
                        <input type="text" clas="form-contro" name="nombre" required maxlength="20">
                    </div>
                    <div class="form-group">
                        <label for="apellido">apellido</label>
                        <input type="text" clas="form-contro" name="apellido" required maxlength="20">
                    </div>
                    <div class="form-group">
                        <label for="direccion">direccion</label>
                        <input type="text" clas="form-contro" name="direccion" required maxlength="20">
                    </div>
                    <div class="form-group">
                        <label for="telefono">telefono</label>
                        <input type="text" clas="form-contro" name="telefono" required maxlength="20">
                    </div>
                    <div class="form-group">
                        <label for="email">email</label>
                        <input type="text" clas="form-contro" name="email" required maxlength="20">
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Guardar">
                        <input type="reset" class="btn btn-default" value="Cancelar">
                        <a href="javascript:history.back()">Regresar al listado</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\example-crud2\resources\views/cliente/create.blade.php ENDPATH**/ ?>