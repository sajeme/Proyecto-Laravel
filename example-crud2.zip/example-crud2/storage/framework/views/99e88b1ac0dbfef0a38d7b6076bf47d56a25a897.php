<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión Clientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h4>Gestion de Clientes
        </h4>
        <div class="row">
            <div class="col-xl-12">
                <form action="<?php echo e(route('cliente.index')); ?>" method="get">
                    <div class="form-row">
                        <div class="col-sm-4 my-1">
                            <input type="text" class="form-control" name="texto" value="<?php echo e($texto); ?>">
                        </div>
                        <div class="col-auto my-1">
                            <input type="submit" class="btn btn-primary" value="Buscar">
                        </div>
                        <div class="col-auto my-1">
                            <a href="<?php echo e(route('cliente.create')); ?>" class="btn btn-success">Nuevo</a>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-xl-12">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Opciones</th>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Dirección</th>
                                <th>Telefono</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($clientes)<=0): ?>
                            <tr>
                                <td colspan="7">No hay apellido similares</td>
                            </tr>
                            <?php else: ?>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('cliente.edit', $cliente->id)); ?>" class="btn btn-warning btn-sm"> Editar </a> 
                                <form action="<?php echo e(route('cliente.destroy', $cliente->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input type="submit" class="btn btn-danger btn-sm" value="Eliminar">
                                </form> </td>
                                <td><?php echo e($cliente->id); ?></td>
                                <td><?php echo e($cliente->nombre); ?></td>
                                <td><?php echo e($cliente->apellido); ?></td>
                                <td><?php echo e($cliente->direccion); ?></td>
                                <td><?php echo e($cliente->telefono); ?></td>
                                <td><?php echo e($cliente->email); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php echo e($clientes->links()); ?>

                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\example-crud2\resources\views/cliente/index.blade.php ENDPATH**/ ?>